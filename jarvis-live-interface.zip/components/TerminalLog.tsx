import React, { useEffect, useRef } from 'react';
import { LogEntry } from '../types';

interface TerminalLogProps {
  logs: LogEntry[];
  themeColor?: 'cyan' | 'red' | 'amber';
}

export const TerminalLog: React.FC<TerminalLogProps> = ({ logs, themeColor = 'cyan' }) => {
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs]);

  const getThemeStyles = () => {
    switch (themeColor) {
      case 'red':
        return {
          border: 'border-red-500/50',
          bg: 'bg-red-950/30',
          jarvisText: 'text-red-400',
          systemText: 'text-red-300'
        };
      case 'amber':
        return {
          border: 'border-amber-500/50',
          bg: 'bg-amber-950/30',
          jarvisText: 'text-amber-400',
          systemText: 'text-amber-300'
        };
      default:
        return {
          border: 'border-cyan-500/50',
          bg: 'bg-slate-900/50',
          jarvisText: 'text-cyan-400',
          systemText: 'text-slate-400'
        };
    }
  };

  const styles = getThemeStyles();

  return (
    <div className={`w-full h-48 md:h-64 ${styles.bg} border ${styles.border} rounded-lg p-4 overflow-y-auto font-mono-tech text-xs md:text-sm backdrop-blur-sm shadow-inner scrollbar-thin scrollbar-thumb-slate-700 scrollbar-track-transparent transition-colors duration-500`}>
      {logs.map((log, index) => (
        <div key={index} className="mb-1.5 leading-snug">
          <span className="opacity-50 mr-2 text-[10px] uppercase">[{log.timestamp}]</span>
          <span className={`font-bold mr-2 ${
            log.sender === 'JARVIS' ? styles.jarvisText : 
            log.sender === 'USER' ? 'text-white' : styles.systemText
          }`}>
            {log.sender}
            {log.sender === 'SYSTEM' ? '' : ':'}
          </span>
          <span className={`${log.sender === 'SYSTEM' ? 'italic opacity-70' : 'opacity-90'}`}>
             {log.sender === 'SYSTEM' ? `>> ${log.message}` : log.message}
          </span>
        </div>
      ))}
      <div ref={bottomRef} />
    </div>
  );
};