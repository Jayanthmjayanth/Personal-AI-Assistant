import React from 'react';

interface ArcReactorProps {
  isActive: boolean;
  amplitude: number;
  colorTheme: 'cyan' | 'red' | 'amber';
}

export const ArcReactor: React.FC<ArcReactorProps> = ({ isActive, amplitude, colorTheme }) => {
  const getThemeColors = () => {
    switch(colorTheme) {
      case 'red': return { 
        core: 'bg-red-500', 
        glow: 'shadow-red-500', 
        border: 'border-red-500', 
        stroke: '#ef4444',
        text: 'text-red-400'
      };
      case 'amber': return { 
        core: 'bg-amber-500', 
        glow: 'shadow-amber-500', 
        border: 'border-amber-500', 
        stroke: '#f59e0b',
        text: 'text-amber-400'
      };
      default: return { 
        core: 'bg-cyan-400', 
        glow: 'shadow-cyan-400', 
        border: 'border-cyan-400', 
        stroke: '#22d3ee',
        text: 'text-cyan-400'
      };
    }
  };

  const colors = getThemeColors();
  
  // Non-linear scaling for more "pop" at lower amplitudes
  const scale = 1 + Math.pow(Math.min(amplitude, 1.5), 0.8) * 0.4;
  
  return (
    <div className="relative flex items-center justify-center w-80 h-80 md:w-[28rem] md:h-[28rem] lg:w-[34rem] lg:h-[34rem]">
      
      {/* --- SVG LAYERS FOR PRECISION GEOMETRY --- */}
      
      {/* Outer Rotating Dashed Ring */}
      <svg className="absolute w-full h-full opacity-30 animate-[spin_60s_linear_infinite]" viewBox="0 0 100 100">
        <circle cx="50" cy="50" r="49" fill="none" stroke={colors.stroke} strokeWidth="0.2" strokeDasharray="1, 4" />
      </svg>
      
      {/* Middle Counter-Rotating Tech Ring */}
      <svg className="absolute w-[85%] h-[85%] opacity-50 animate-[spin_30s_linear_infinite_reverse]" viewBox="0 0 100 100">
        <path d="M 50 2 A 48 48 0 0 1 98 50" fill="none" stroke={colors.stroke} strokeWidth="0.5" strokeDasharray="10, 2" />
        <path d="M 50 98 A 48 48 0 0 1 2 50" fill="none" stroke={colors.stroke} strokeWidth="0.5" strokeDasharray="10, 2" />
      </svg>

      {/* Inner Fast Rotating Ring */}
      <svg className="absolute w-[70%] h-[70%] opacity-40 animate-[spin_10s_linear_infinite]" viewBox="0 0 100 100">
        <circle cx="50" cy="50" r="48" fill="none" stroke={colors.stroke} strokeWidth="0.8" strokeDasharray="30, 70" />
      </svg>

      {/* Static Crosshairs */}
      <svg className="absolute w-[60%] h-[60%] opacity-20" viewBox="0 0 100 100">
        <line x1="50" y1="0" x2="50" y2="10" stroke={colors.stroke} strokeWidth="1" />
        <line x1="50" y1="90" x2="50" y2="100" stroke={colors.stroke} strokeWidth="1" />
        <line x1="0" y1="50" x2="10" y2="50" stroke={colors.stroke} strokeWidth="1" />
        <line x1="90" y1="50" x2="100" y2="50" stroke={colors.stroke} strokeWidth="1" />
      </svg>

      {/* --- CORE REACTOR ASSEMBLY --- */}

      {/* Glass Casing with Inner Shadows */}
      <div className={`relative w-[50%] h-[50%] rounded-full border-2 ${colors.border} flex items-center justify-center bg-slate-950 shadow-[0_0_50px_rgba(0,0,0,0.9)] z-10 overflow-hidden`}>
        
        {/* Inner Tech Grid Background */}
        <div className="absolute inset-0 opacity-30" 
             style={{
               backgroundImage: `radial-gradient(${colors.stroke} 1px, transparent 1px)`, 
               backgroundSize: '8px 8px',
               maskImage: 'radial-gradient(circle, black 40%, transparent 100%)'
             }}>
        </div>

        {/* The "Plasma" Core */}
        <div 
          className={`w-[60%] h-[60%] rounded-full ${colors.core} blur-[20px] opacity-60 absolute transition-transform duration-75 will-change-transform`}
          style={{ transform: `scale(${scale})` }}
        />
        
        {/* The "White Hot" Center - Gives the blinding light effect */}
        <div 
          className={`w-[35%] h-[35%] rounded-full bg-white blur-[8px] opacity-90 absolute transition-transform duration-75 shadow-[0_0_20px_white]`}
          style={{ transform: `scale(${Math.max(1, scale * 0.8)})` }}
        />
        
        {/* Rim Lighting (Inner Shadow) */}
        <div className={`absolute w-full h-full rounded-full border-4 ${colors.border} opacity-40 shadow-[inset_0_0_30px_rgba(0,0,0,1)]`}></div>
      </div>

      {/* Outer Atmospheric Glow (Bloom) */}
      <div 
        className={`absolute w-[60%] h-[60%] rounded-full ${colors.core} blur-[80px] opacity-20 pointer-events-none transition-all duration-100`}
        style={{ opacity: 0.1 + (amplitude * 0.2) }}
      />
      
      {/* Status Label */}
      <div className="absolute -bottom-16 md:-bottom-20 w-full text-center pointer-events-none">
         <p className={`font-mono-tech text-xs md:text-sm tracking-[0.5em] ${colors.text} opacity-60 mb-2`}>SYSTEM STATUS</p>
         <p className={`font-mono-tech text-xl md:text-3xl tracking-[0.2em] font-bold ${isActive ? 'animate-pulse text-white' : 'opacity-50 text-slate-500'}`}>
            {isActive ? 'ONLINE' : 'STANDBY'}
         </p>
      </div>
    </div>
  );
};