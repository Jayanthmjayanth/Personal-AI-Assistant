export enum ConnectionState {
  DISCONNECTED = 'DISCONNECTED',
  CONNECTING = 'CONNECTING',
  CONNECTED = 'CONNECTED',
  ERROR = 'ERROR'
}

export interface LogEntry {
  timestamp: string;
  sender: 'JARVIS' | 'USER' | 'SYSTEM';
  message: string;
}

export type Language = 'english' | 'kannada' | 'mixed';

export interface SystemStatus {
  battery: number;
  cpuLoad: number;
  location: string;
  themeColor: 'cyan' | 'red' | 'amber';
}