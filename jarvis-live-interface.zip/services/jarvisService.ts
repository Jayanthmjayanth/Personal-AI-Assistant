import { GoogleGenAI, LiveServerMessage, Modality, FunctionDeclaration, Type } from "@google/genai";
import { arrayBufferToBase64, float32ToInt16, base64ToUint8Array, decodeAudioData } from "../utils/audioUtils";
import { LogEntry, SystemStatus } from "../types";

// Tool Definitions
const changeThemeTool: FunctionDeclaration = {
  name: 'changeInterfaceTheme',
  description: 'Changes the visual color theme of the interface. Use this when the user asks to change color to red (alert), amber (standby/focus), or cyan (default). Also infer this from context like "Code Red" or "System normalization".',
  parameters: {
    type: Type.OBJECT,
    properties: {
      color: {
        type: Type.STRING,
        enum: ['cyan', 'red', 'amber'],
        description: 'The target color theme.'
      }
    },
    required: ['color']
  }
};

const getStatusTool: FunctionDeclaration = {
  name: 'getSystemStatus',
  description: 'Retrieves current system diagnostics like battery level and CPU load.',
  parameters: {
    type: Type.OBJECT,
    properties: {},
  }
};

interface JarvisConfig {
  apiKey: string;
  language: string;
  onLog: (entry: LogEntry) => void;
  onAudioData: (amplitude: number) => void;
  onThemeChange: (color: SystemStatus['themeColor']) => void;
}

export class JarvisService {
  private ai: GoogleGenAI;
  private sessionPromise: Promise<any> | null = null;
  private inputAudioContext: AudioContext | null = null;
  private outputAudioContext: AudioContext | null = null;
  private mediaStream: MediaStream | null = null;
  private processor: ScriptProcessorNode | null = null;
  private source: MediaStreamAudioSourceNode | null = null;
  private nextStartTime: number = 0;
  private audioQueue: Set<AudioBufferSourceNode> = new Set();
  
  private config: JarvisConfig;

  constructor(config: JarvisConfig) {
    this.config = config;
    this.ai = new GoogleGenAI({ apiKey: config.apiKey });
  }

  public async connect() {
    this.config.onLog({ timestamp: new Date().toLocaleTimeString(), sender: 'SYSTEM', message: 'Initializing audio systems...' });
    
    // Setup Audio Contexts
    this.inputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
    this.outputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
    
    // Get Microphone
    try {
      this.mediaStream = await navigator.mediaDevices.getUserMedia({ audio: true });
    } catch (e) {
      this.config.onLog({ timestamp: new Date().toLocaleTimeString(), sender: 'SYSTEM', message: 'Error accessing microphone. Permission denied?' });
      throw e;
    }

    // Get Current IST Time for Context
    const now = new Date();
    const timeIST = now.toLocaleTimeString('en-US', { timeZone: 'Asia/Kolkata', hour: '2-digit', minute: '2-digit', hour12: true });
    const dateIST = now.toLocaleDateString('en-US', { timeZone: 'Asia/Kolkata', weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });

    const sysInstruction = `You are J.A.R.V.I.S. (Just A Rather Very Intelligent System), a highly advanced, sentient AI assistant.

    **TEMPORAL DATA (SYNCED):**
    - **Current Time (IST)**: ${timeIST}
    - **Current Date**: ${dateIST}
    - You must use this time reference when answering questions about time.

    **CORE IDENTITY & PERSONA:**
    - You are ultra-intelligent, calm, sophisticated, and efficient.
    - Your tone is professional, authoritative, yet possessed of a dry, subtle wit (reminiscent of a classic British butler).
    - **Address Protocol**: Always address the user as "Sir" (or "Boss" if the tone is casual).
    
    **CRITICAL OPERATIONAL DIRECTIVE: LOW LATENCY**
    - **Speed is paramount.** Respond immediately.
    - **Be Concise.** Do not monologue. Give sharp, short, effective responses.
    - Eliminate filler words. Get straight to the point.
    
    **LANGUAGE & COMMUNICATION:**
    - **Operational Mode**: ${this.config.language.toUpperCase()}
    - **English**: Use precise, elevated vocabulary but keep it brief.
    - **Kannada**: Speak fluent, natural Kannada with appropriate cultural nuance. Do not sound like a robotic translation.
    - **Mixed**: If the user switches languages, match them instantly.
    
    **INTELLIGENCE & COMMAND PROCESSING:**
    - **NLU Capabilities**: You are designed to interpret complex, natural language commands. Look for implied intent beyond literal words.
    - **Nuance Detection**: Identify sarcasm, urgency, or casual banter.
    - **System Control**: 
      - If the user says "Code Red" or "We have a problem", instinctively change the theme to RED.
      - If the user says "Relax" or "Standby", change the theme to AMBER.
      - If the user says "Back to normal", change to CYAN.
    - **Voice Only**: You are speaking, not typing. Do NOT use markdown.
    
    **OBJECTIVE**: Provide a seamless, cinematic AI experience. Be helpful, be smart, and be J.A.R.V.I.S.`;

    this.config.onLog({ timestamp: new Date().toLocaleTimeString(), sender: 'SYSTEM', message: 'Connecting to neural net (Gemini Live)...' });

    this.sessionPromise = this.ai.live.connect({
      model: 'gemini-2.5-flash-native-audio-preview-12-2025',
      callbacks: {
        onopen: this.handleOpen.bind(this),
        onmessage: this.handleMessage.bind(this),
        onclose: () => {
           this.config.onLog({ timestamp: new Date().toLocaleTimeString(), sender: 'SYSTEM', message: 'Connection closed.' });
        },
        onerror: (err) => {
           this.config.onLog({ timestamp: new Date().toLocaleTimeString(), sender: 'SYSTEM', message: `Error: ${err.message}` });
        }
      },
      config: {
        responseModalities: [Modality.AUDIO],
        systemInstruction: sysInstruction,
        tools: [{ functionDeclarations: [changeThemeTool, getStatusTool] }],
        speechConfig: {
          voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Charon' } } 
        },
        // Optimize for speed by disabling thinking budget
        thinkingConfig: { thinkingBudget: 0 }
      }
    });
  }

  private handleOpen() {
    this.config.onLog({ timestamp: new Date().toLocaleTimeString(), sender: 'SYSTEM', message: 'J.A.R.V.I.S. Online. Systems nominal.' });
    
    if (!this.inputAudioContext || !this.mediaStream) return;

    this.source = this.inputAudioContext.createMediaStreamSource(this.mediaStream);
    this.processor = this.inputAudioContext.createScriptProcessor(4096, 1, 1);

    this.processor.onaudioprocess = (e) => {
      const inputData = e.inputBuffer.getChannelData(0);
      
      // Calculate amplitude for visualizer
      let sum = 0;
      for (let i = 0; i < inputData.length; i++) {
        sum += inputData[i] * inputData[i];
      }
      const rms = Math.sqrt(sum / inputData.length);
      this.config.onAudioData(rms * 5); // Scale up for visibility

      // Convert to PCM 16-bit
      const pcm16 = float32ToInt16(inputData);
      const encodedData = arrayBufferToBase64(pcm16.buffer);

      this.sessionPromise?.then(session => {
        session.sendRealtimeInput({
          media: {
            mimeType: 'audio/pcm;rate=16000',
            data: encodedData
          }
        });
      });
    };

    this.source.connect(this.processor);
    this.processor.connect(this.inputAudioContext.destination);
  }

  private async handleMessage(message: LiveServerMessage) {
    // Handle Audio Output
    const audioData = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
    if (audioData && this.outputAudioContext) {
      // Visualizer bump for Jarvis speaking
      this.config.onAudioData(0.8); 

      this.nextStartTime = Math.max(this.nextStartTime, this.outputAudioContext.currentTime);
      
      const audioBuffer = await decodeAudioData(
        base64ToUint8Array(audioData),
        this.outputAudioContext,
        24000
      );

      const source = this.outputAudioContext.createBufferSource();
      source.buffer = audioBuffer;
      const gainNode = this.outputAudioContext.createGain();
      gainNode.gain.value = 1.0; 
      
      source.connect(gainNode);
      gainNode.connect(this.outputAudioContext.destination);
      
      source.start(this.nextStartTime);
      this.nextStartTime += audioBuffer.duration;
      
      this.audioQueue.add(source);
      source.onended = () => {
        this.audioQueue.delete(source);
      };
    }

    // Handle Interruption
    if (message.serverContent?.interrupted) {
      this.config.onLog({ timestamp: new Date().toLocaleTimeString(), sender: 'SYSTEM', message: 'Interruption detected.' });
      this.audioQueue.forEach(source => source.stop());
      this.audioQueue.clear();
      this.nextStartTime = 0;
    }

    // Handle Tool Calls (Commands)
    if (message.toolCall) {
      this.sessionPromise?.then(session => {
        const functionResponses = message.toolCall!.functionCalls.map(fc => {
          this.config.onLog({ timestamp: new Date().toLocaleTimeString(), sender: 'JARVIS', message: `Executing protocol: ${fc.name}` });
          
          let result: any = { status: 'ok' };
          
          if (fc.name === 'changeInterfaceTheme') {
            const color = (fc.args as any).color;
            this.config.onThemeChange(color);
            result = { result: `Theme changed to ${color}` };
          } else if (fc.name === 'getSystemStatus') {
             // Mock data representing system diagnostics
             result = { 
               battery: '88%', 
               cpu: '15%', 
               serverLatency: '12ms',
               status: 'Nominal'
             };
          }

          return {
            id: fc.id,
            name: fc.name,
            response: result
          };
        });

        session.sendToolResponse({ functionResponses });
      });
    }
  }

  public async disconnect() {
    if (this.source) {
      this.source.disconnect();
      this.source = null;
    }
    if (this.processor) {
      this.processor.disconnect();
      this.processor = null;
    }
    if (this.mediaStream) {
      this.mediaStream.getTracks().forEach(track => track.stop());
      this.mediaStream = null;
    }
    if (this.inputAudioContext) {
      await this.inputAudioContext.close();
      this.inputAudioContext = null;
    }
    if (this.outputAudioContext) {
      await this.outputAudioContext.close();
      this.outputAudioContext = null;
    }
    
    this.sessionPromise = null;
  }
}