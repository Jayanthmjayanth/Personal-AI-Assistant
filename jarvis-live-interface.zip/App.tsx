import React, { useState, useEffect, useRef } from 'react';
import { ConnectionState, Language, SystemStatus } from './types';
import { JarvisService } from './services/jarvisService';
import { ArcReactor } from './components/ArcReactor';

// Decorative Component for scrolling data
const DataStream: React.FC<{ color: string, align: 'left' | 'right' }> = ({ color, align }) => {
  const [lines, setLines] = useState<string[]>([]);
  
  useEffect(() => {
    const interval = setInterval(() => {
      setLines(prev => {
        const newLine = Math.random().toString(16).substring(2, 10).toUpperCase();
        const next = [...prev, `0x${newLine}`];
        if (next.length > 8) next.shift();
        return next;
      });
    }, 150);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className={`flex flex-col text-[10px] font-mono-tech ${color} opacity-40 leading-tight ${align === 'right' ? 'text-right' : 'text-left'}`}>
      {lines.map((l, i) => <span key={i}>{l}</span>)}
    </div>
  );
};

const App: React.FC = () => {
  const [connectionState, setConnectionState] = useState<ConnectionState>(ConnectionState.DISCONNECTED);
  const [amplitude, setAmplitude] = useState<number>(0);
  const [language, setLanguage] = useState<Language>('english');
  const [themeColor, setThemeColor] = useState<SystemStatus['themeColor']>('cyan');
  const [time, setTime] = useState<string>('');
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  
  const jarvisRef = useRef<JarvisService | null>(null);

  // Install Prompt Listener
  useEffect(() => {
    const handler = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };
    window.addEventListener('beforeinstallprompt', handler);
    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);

  const handleInstall = async () => {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === 'accepted') {
      setDeferredPrompt(null);
    }
  };

  // Clock Timer (IST)
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      // Format: HH:MM:SS in 24h format for Sci-Fi look, set to Asia/Kolkata
      const timeStr = now.toLocaleTimeString('en-US', { 
        timeZone: 'Asia/Kolkata',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: false
      });
      setTime(timeStr);
    };
    
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  const handleStart = async () => {
    if (!process.env.API_KEY) {
      alert('API_KEY missing in environment variables.');
      return;
    }

    try {
      setConnectionState(ConnectionState.CONNECTING);
      
      jarvisRef.current = new JarvisService({
        apiKey: process.env.API_KEY,
        language: language,
        onLog: (entry) => console.log(`[${entry.sender}] ${entry.message}`),
        onAudioData: (amp) => setAmplitude(amp),
        onThemeChange: (color) => setThemeColor(color)
      });

      await jarvisRef.current.connect();
      setConnectionState(ConnectionState.CONNECTED);
    } catch (e) {
      console.error(e);
      setConnectionState(ConnectionState.ERROR);
    }
  };

  const handleStop = async () => {
    if (jarvisRef.current) {
      await jarvisRef.current.disconnect();
      jarvisRef.current = null;
    }
    setConnectionState(ConnectionState.DISCONNECTED);
    setAmplitude(0);
  };

  const getThemeHex = () => {
    switch(themeColor) {
      case 'red': return 'text-red-500 border-red-500';
      case 'amber': return 'text-amber-500 border-amber-500';
      default: return 'text-cyan-400 border-cyan-400';
    }
  };

  const getButtonClass = (active: boolean) => {
    const base = "w-full max-w-sm md:w-80 px-6 py-4 font-bold tracking-[0.25em] transition-all duration-300 uppercase text-sm md:text-base font-mono-tech relative overflow-hidden backdrop-blur-sm ";
    
    if (active) {
       switch(themeColor) {
        case 'red': return base + "bg-red-500/10 border border-red-500 text-red-100 shadow-[0_0_30px_rgba(239,68,68,0.3)] hover:bg-red-500/20 hover:shadow-[0_0_50px_rgba(239,68,68,0.5)]";
        case 'amber': return base + "bg-amber-500/10 border border-amber-500 text-amber-100 shadow-[0_0_30px_rgba(245,158,11,0.3)] hover:bg-amber-500/20 hover:shadow-[0_0_50px_rgba(245,158,11,0.5)]";
        default: return base + "bg-cyan-500/10 border border-cyan-400 text-cyan-100 shadow-[0_0_30px_rgba(6,182,212,0.3)] hover:bg-cyan-500/20 hover:shadow-[0_0_50px_rgba(6,182,212,0.5)]";
      }
    }
    return base + "border border-slate-700 text-slate-500 hover:border-slate-500 hover:text-slate-300";
  };

  return (
    <div className={`min-h-[100dvh] w-full flex flex-col relative overflow-hidden bg-slate-950 text-slate-200 transition-colors duration-1000 ${themeColor === 'red' ? 'shadow-[inset_0_0_100px_rgba(127,29,29,0.2)]' : ''}`}>
      
      {/* --- HUD OVERLAYS --- */}
      
      {/* Scanlines & Vignette */}
      <div className="scanlines"></div>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_0%,rgba(0,0,0,0.8)_100%)] pointer-events-none z-30"></div>
      
      {/* Top Left HUD Info */}
      <div className="absolute top-6 left-6 md:top-10 md:left-10 z-20 flex flex-col gap-1 pointer-events-none hidden sm:flex">
         <div className={`text-[10px] tracking-[0.2em] font-mono-tech opacity-60 ${getThemeHex()}`}>SYS.OS.V4.2.1</div>
         <div className="text-[10px] text-slate-500 font-mono-tech">COORDS: 12.9716° N, 77.5946° E</div>
      </div>

      {/* Top Right HUD Info - CLOCK */}
      <div className="absolute top-6 right-6 md:top-10 md:right-10 z-20 flex flex-col items-end gap-1 pointer-events-none hidden sm:flex">
         <div className={`text-2xl md:text-3xl font-bold tracking-widest font-mono-tech ${getThemeHex()} drop-shadow-[0_0_5px_rgba(255,255,255,0.5)]`}>
            {time} <span className="text-xs align-top opacity-50">IST</span>
         </div>
         <div className={`text-[10px] tracking-[0.2em] font-mono-tech opacity-60 ${getThemeHex()}`}>NET: SECURE</div>
         <div className="text-[10px] text-slate-500 font-mono-tech">LATENCY: 12ms</div>
      </div>

      {/* Bottom Right Data Stream */}
      <div className="absolute bottom-6 right-6 md:bottom-10 md:right-10 z-20 hidden md:block pointer-events-none">
        <DataStream color={getThemeHex()} align="right" />
      </div>

      {/* --- MAIN UI --- */}

      {/* Header */}
      <div className="w-full flex flex-col md:flex-row justify-between items-center md:items-start z-40 p-6 md:p-10 relative">
        <div className="flex flex-col items-center md:items-start">
           <h1 className={`text-5xl md:text-7xl font-bold tracking-[0.1em] font-mono-tech ${getThemeHex().split(' ')[0]} drop-shadow-[0_0_10px_rgba(255,255,255,0.3)] text-center md:text-left leading-none`}>
             JARVIS
           </h1>
           <div className="flex items-center gap-3 mt-2">
             <div className={`h-1.5 w-1.5 rounded-full ${connectionState === ConnectionState.CONNECTED ? 'bg-emerald-400 animate-pulse shadow-[0_0_8px_#34d399]' : 'bg-red-500 shadow-[0_0_8px_#ef4444]'}`}></div>
             <span className="text-[10px] md:text-xs text-slate-500 tracking-[0.3em] font-mono-tech uppercase">
               {connectionState}
             </span>
           </div>
        </div>
        
        {/* Controls: Language & Install */}
        <div className="mt-4 md:mt-0 flex flex-col items-end gap-2">
          
          {/* Install Button (Only visible on mobile/PWA capable browsers) */}
          {deferredPrompt && (
            <button 
              onClick={handleInstall}
              className={`px-4 py-2 text-[10px] md:text-xs tracking-widest uppercase transition-all duration-300 rounded border font-mono-tech bg-emerald-900/40 border-emerald-500/50 text-emerald-300 hover:bg-emerald-800/60 hover:text-emerald-100 shadow-[0_0_10px_rgba(16,185,129,0.3)] animate-pulse`}
            >
              [ INSTALL PROTOCOL ]
            </button>
          )}

          {/* Language Selection */}
          <div className="flex items-center gap-1 bg-slate-900/80 p-1 rounded border border-slate-800 backdrop-blur-md">
             {['english', 'kannada', 'mixed'].map((lang) => (
               <button 
                 key={lang}
                 onClick={() => setLanguage(lang as Language)} 
                 className={`px-4 py-1.5 text-[10px] md:text-xs tracking-widest uppercase transition-all duration-300 rounded-sm font-mono-tech ${language === lang ? 'bg-slate-800 text-white shadow-inner' : 'text-slate-600 hover:text-slate-400'}`}
                 disabled={connectionState === ConnectionState.CONNECTED}
               >
                 {lang}
               </button>
             ))}
          </div>
        </div>
      </div>

      {/* Content Center */}
      <div className="flex-1 flex flex-col items-center justify-center w-full relative z-10 pb-20 gap-16 md:gap-20 crt-flicker">
        
        <div className="relative transform transition-transform duration-1000">
           <ArcReactor 
            isActive={connectionState === ConnectionState.CONNECTED} 
            amplitude={amplitude} 
            colorTheme={themeColor}
          />
        </div>
        
        {/* Glass Button */}
        <div className="w-full flex justify-center z-50 px-6">
          {connectionState === ConnectionState.DISCONNECTED || connectionState === ConnectionState.ERROR ? (
            <button onClick={handleStart} className={getButtonClass(true)}>
              INITIALIZE SYSTEM
            </button>
          ) : (
             <button onClick={handleStop} className={getButtonClass(false)}>
              TERMINATE LINK
            </button>
          )}
        </div>
      </div>

    </div>
  );
};

export default App;